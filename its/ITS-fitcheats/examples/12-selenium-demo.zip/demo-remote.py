# -*- coding: utf-8 -*-
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import Select
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
import unittest, time, re

COMMAND_EXECUTOR = 'http://pcsmrcka.fit.vutbr.cz:4444/wd/hub'
BASE_URL = 'http://pcsmrcka.fit.vutbr.cz:8123/'

class Install(unittest.TestCase):
    def setUp(self):
        self.driver = webdriver.Remote(
                command_executor=COMMAND_EXECUTOR,
                desired_capabilities=webdriver.common.desired_capabilities.DesiredCapabilities.FIREFOX
                )
# zmena velikosti okna pro zachovani stejnych CSS stylu/stejneho vzhledu
# jako pri tvorbe testu
        self.driver.set_window_size(1280,800)
        self.driver.implicitly_wait(30)
        self.base_url = BASE_URL
        self.verificationErrors = []
        self.accept_next_alert = True
    
    def login_to_wordpress(self):
        driver = self.driver
        driver.get(self.base_url + "/wordpress/")
        driver.find_element_by_link_text("Log in").click()
        driver.find_element_by_id("user_login").clear()
        driver.find_element_by_id("user_login").send_keys("wordpress")
        driver.find_element_by_id("user_pass").clear()
        driver.find_element_by_id("user_pass").send_keys("sheemohh")
        driver.find_element_by_id("wp-submit").click()
# zde by mel prijit assert, ze jsme na administratorske strance wordpressu.
# Metody assertu jsou v tride unittest.TestCase, viz:
# https://docs.python.org/2/library/unittest.html#assert-methods
# V pripade, ze se neco nepovedlo, mozna by se nam hodil screenshot, viz:
# http://selenium-python.readthedocs.org/en/latest/faq.html#how-to-take-screenshot-of-the-current-window

    def test_install(self):
        self.login_to_wordpress()
        driver = self.driver
        driver.find_element_by_xpath("//li[@id='menu-plugins']/a/div[3]").click()
        driver.find_element_by_css_selector("a.add-new-h2").click()
        driver.find_element_by_name("s").clear()
        driver.find_element_by_name("s").send_keys("groups")
        driver.find_element_by_id("search-submit").click()
# Toto by melo byt prvni tlacitko vlevo nahore "Install now" (prvni nalezeny
# plugin).
# .find_element_by_link_text("Install now") by totiz nemuselo odpovidat prvnimu
# nalezenemu pluginu
        driver.find_element_by_xpath("//div/div/div/div[2]/ul/li/a").click()
        driver.find_element_by_link_text("Activate Plugin").click()
    
    def test_uninstall(self):
        self.login_to_wordpress()
        driver = self.driver
        driver.find_element_by_xpath("//li[@id='menu-plugins']/a/div[3]").click()
        driver.find_element_by_xpath("//tr[@id='groups']/td/div/span/a").click()
        driver.find_element_by_css_selector("#groups > td.plugin-title > div.row-actions.visible > span.delete > a.delete").click()
        driver.find_element_by_id("submit").click()
    
    def is_element_present(self, how, what):
        try: self.driver.find_element(by=how, value=what)
        except NoSuchElementException, e: return False
        return True
    
    def is_alert_present(self):
        try: self.driver.switch_to_alert()
        except NoAlertPresentException, e: return False
        return True
    
    def close_alert_and_get_its_text(self):
        try:
            alert = self.driver.switch_to_alert()
            alert_text = alert.text
            if self.accept_next_alert:
                alert.accept()
            else:
                alert.dismiss()
            return alert_text
        finally: self.accept_next_alert = True
    
    def tearDown(self):
        self.driver.quit()
        self.assertEqual([], self.verificationErrors)

if __name__ == "__main__":
    unittest.main()
