/*  Knihovna na pretizeni nekterych knihovnich nebo systemovych volani
 *  v projektech.
 *  Pouziti:
 *  $ make
 *  $ export STUB_CLOCK=1425388903
 *  $ LD_PRELOAD=./stub_time.so date
 */
#define _GNU_SOURCE
#include <dlfcn.h>

#include <time.h>
#include <stdlib.h>

int clock_gettime(clockid_t clk_id, struct timespec *tp)
{
    static int (*std_call)();
    if (clk_id == CLOCK_REALTIME)
    {
        char *stubclk = getenv("STUB_CLOCK");
        if (stubclk)
        {
            tp->tv_sec = atol(stubclk);
            tp->tv_nsec = 0;
            return 0;
        }
    }
    if (!std_call)
        std_call = (int (*)()) dlsym(RTLD_NEXT, "clock_gettime");
    return std_call(clk_id, tp);
}
