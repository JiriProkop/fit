#include <stdio.h>
#include <string.h>

int main(int argc, char **argv)
{
    int i = 1;
    while (i < argc && strcmp(argv[i], "-h") != 0)
    {
        printf("arg[%i] = %s\n", i, argv[i]);
        i++;
    }
    return 0;
}
