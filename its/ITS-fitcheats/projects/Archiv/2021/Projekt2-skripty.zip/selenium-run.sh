#!/bin/bash

NNODES=60
NODEIMGFF=docker.io/selenium/node-firefox
NODEIMGDEBUG=docker.io/selenium/node-firefox-debug
NODEIMGDEBUG=docker.io/selenium/node-chrome-debug
NODEIMGCHROME=docker.io/selenium/node-chrome
HUBIMG=docker.io/selenium/hub
HUBNAME=selenium-hub

PNAME=$0

die()
{
    echo "error: $@" >&2
    exit 1
}

usage()
{
    echo "usage: $PNAME options"
    echo "options:"
    echo "   -h         run hub"
    echo "   -n NUMBER  run NUMBER of nodes (half firefox, half chrome)"
    echo "   -f NUMBER  run NUMBER of firefox nodes (overrides -n)"
    echo "   -c NUMBER  run NUMBER of chrome nodes (overrides -n)"
    echo "   -d         run firefox debug node (overrides -n)"
    echo "   -a         run hub and $NNODES nodes"
    echo "   -s         stop hub and all nodes"
    exit 0
}

container_running()
{
    docker ps | grep -q "$1"
}

hub_running()
{
    container_running selenium-hub
}

run_hub()
{
    if ! hub_running; then
        echo Running hub ...
        docker run -d -p 4444:4444 --name $HUBNAME $HUBIMG >/dev/null ||
            die "selenium hub"
    else
        echo Hub is already running ...
    fi
}

# $1 = image
run_node()
{
    hub_running || run_hub
    docker run -d --link $HUBNAME:hub -v /dev/shm:/dev/shm "$@" >/dev/null
}

run_node_ff()
{
    run_node $NODEIMGFF
}

run_node_chrome()
{
    run_node $NODEIMGCHROME
}

run_node_debug()
{
    container_running selenium-debug && return
    run_node -h selenium-debug --name selenium-debug -p 5919:5900 $NODEIMGDEBUG
}

# $1 = image
get_container_ids()
{
    docker ps -a --format='{{.ID}}' -f ancestor=$1
}

# $1 = parent image
# $2 (optional) = short description
stop_delete()
{
    containers=$(get_container_ids $1)
    if [ -n "$containers" ]; then
        echo "Stopping $(echo "$containers" | wc -l) container(s) $2 ..."
        docker stop $containers >/dev/null
        echo "Removing containers $2 ..."
        docker rm $containers >/dev/null
    fi
}

clean_nodes()
{
    stop_delete $NODEIMGFF firefox
    stop_delete $NODEIMGCHROME chrome
    stop_delete $NODEIMGDEBUG firefox-debug
}

clean_hub()
{
    stop_delete $HUBIMG hub
}

clean_all()
{
    clean_nodes
    clean_hub
}

[ -z "$1" ] && usage

hub=
nodes=0
ffnodes=0
chromenodes=0
debugnodes=0
while getopts ahn:f:c:ds opt; do
    case $opt in
        a) hub=1; nodes=$NNODES;;
        h) hub=1;;
        n) nodes=$OPTARG;;
        f) ffnodes=$OPTARG;;
        c) chromenodes=$OPTARG;;
        d) debugnodes=1
           ffnodes=0
           chromenodes=0;;
        s) clean_all
            exit 0;;
        *) usage;;
    esac
done
shift $((OPTIND-1))

if [ -n "$hub" ]; then
    run_hub
fi

if [ $ffnodes -eq 0 -a $chromenodes -eq 0 ]; then
    ffnodes=$((nodes/2))
    chromenodes=$((nodes-ffnodes))
fi
for i in `seq $ffnodes`; do
    echo Running firefox node $i ...
    run_node_ff
done
for i in `seq $chromenodes`; do
    echo Running chrome node $i ...
    run_node_chrome
done
for i in `seq $debugnodes`; do
    echo Running firefox-debug node $i ...
    run_node_debug
done
