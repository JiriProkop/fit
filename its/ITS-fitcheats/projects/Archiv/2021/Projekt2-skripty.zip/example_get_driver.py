# ...
from selenium import webdriver
from selenium.webdriver.common.desired_capabilities import DesiredCapabilities
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.common.exceptions import NoAlertPresentException
from selenium.common.exceptions import WebDriverException

# ...
class ...
    def ensure_driver(self):
        '''Get Chrome/Firefox driver from Selenium Hub'''
        if self.driver != None:
            return
        try:
            self.driver = webdriver.Remote(
                    command_executor='http://localhost:4444/wd/hub',
                    desired_capabilities=DesiredCapabilities.CHROME)
        except WebDriverException:
            self.driver = webdriver.Remote(
                    command_executor='http://localhost:4444/wd/hub',
                    desired_capabilities=DesiredCapabilities.FIREFOX)
        self.driver.implicitly_wait(15)
        self.base_url = "http://localhost:8080/VALU3S"
