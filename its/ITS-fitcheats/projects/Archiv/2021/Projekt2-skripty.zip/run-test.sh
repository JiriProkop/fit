#!/bin/sh

die() {
    echo "error: $*" >&2
    exit 1
}

cd $(dirname $0)
sh ./selenium-run.sh -d >/dev/null || die "docker run node"
behave
sh ./selenium-run.sh -s >/dev/null || dir "docker stop node"
